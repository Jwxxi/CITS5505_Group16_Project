//This chunk handles the matrix-style rain effect showing "Expense Tracker" in sequence.

var r = 255 - 0.1 * 255,
    g = 255 - 0.1 * 255,
    b = 255 - 0.1 * 255;

var interval = 0.95,
    speed = 30;

// grab our canvas and getContext
const canvas = document.getElementById('rain'),
      ctx = canvas.getContext('2d');

// set up drawing options
ctx.lineWidth = 1 * devicePixelRatio;
const fontsize = 20 * devicePixelRatio,
      colWidth = fontsize;

var w, h, cols, drops;
function resizeCanvas() {
  w = window.innerWidth * devicePixelRatio;
  h = window.innerHeight * devicePixelRatio;
  canvas.width = w;
  canvas.height = h;
  canvas.style.width = w / devicePixelRatio + 'px';
  canvas.style.height = h / devicePixelRatio + 'px';
  cols = Math.floor(w / colWidth);
  if (!drops || drops.length < cols) {
    drops = new Array(cols).fill(0);
  }
}

// initial setup
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// the text we want to rain, one char at a time
const text = 'Expense Tracker';
let idx = 0;

// draw loop
function drawRain() {
  // fade background a bit
  ctx.fillStyle = `rgba(${r},${g},${b},0.1)`;
  ctx.fillRect(0, 0, w, h);

  for (let i = 0; i < cols; i++) {
    // random-ish color for each drop
    ctx.fillStyle = ['#3385E5','#09C','#A6C','#93C','#9C0','#FB3','#F80','#F44','#C00'][Math.floor(Math.random()*9)];
    ctx.font = `${fontsize}px "Poppins", sans-serif`;

    // pick next char in sequence
    const ch = text[idx];
    idx = (idx + 1) % text.length;

    // x, y coords
    const x = i * colWidth;
    const y = (drops[i] + 1) * fontsize;

    ctx.fillText(ch, x, y);

    // reset drop or move it down
    drops[i] = y >= h && Math.random() > interval ? 0 : drops[i] + 1;
  }
}

// start the rain
drawRain();
setInterval(drawRain, 60 - speed);

// 🎉 Now let's wire up the sign-up form: validation, console logging, floating labels.

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('signupForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      if (!this.checkValidity()) {
        e.preventDefault();
        e.stopPropagation();
      } else {
        e.preventDefault();
        // grab the values
        const data = new FormData(this);
        console.log('Registration data:', {
          name: data.get('name'),
          email: data.get('email'),
          password: data.get('password')
        });
        alert('Registration successful! You can now sign in.');
        this.reset();
      }
      this.classList.add('was-validated');
    });
  }

  // floating label trick
  document.querySelectorAll('.input-group input').forEach(input => {
    input.addEventListener('focus', () =>
      input.nextElementSibling.classList.add('active')
    );
    input.addEventListener('blur', () => {
      if (!input.value)
        input.nextElementSibling.classList.remove('active');
    });
    if (input.value)
      input.nextElementSibling.classList.add('active');
  });
});
